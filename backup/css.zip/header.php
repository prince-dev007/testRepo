<!DOCTYPE html>
<html>
<head>
	<title>The Roof Store</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/fonts.css">
	<link rel="stylesheet" href="css/all.css">
</head>
<body>
<header class="raisin-black font-gray">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 landing-page text-center">
				<img src="images/sss-logo.png" alt="Don't re-roof-Weatherproof at 1/2 the cost">
			</div>
		</div>
	</div>
</header>